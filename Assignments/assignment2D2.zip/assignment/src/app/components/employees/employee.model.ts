export interface employee{
    firstName: string;
    lastName: string;
    age: number;
    id : string;
    jobTitle: string;
    salary: number;
}