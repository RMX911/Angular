import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductDataService {

  products: any = [
    {
      name: 'Nokia 5.1 Plus',
      price: 8999,
      image: '',
      description: 'Good Nokia Phone'
    },
    {
      name: 'Samsung A10s',
      price: 10999,
      image: '',
      description: 'Good Samsung Phone'
    },
    {
      name: 'Redmi Mi Note 5 Pro',
      price: 12999,
      image: '',
      description: 'Good Redmi Phone'
    },
    {
      name: 'Vivo Y2',
      price: 9500,
      image: '',
      description: 'Good Vivo Phone'
    },
  ];

  getAllData(){
    return this.products; 
  }

  constructor() { }
}
