import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { ProductDataService } from '../../services/product-data.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css'],
})
export class ProductDetailsComponent {
  name: string = '';
  products: any;

  constructor(
    private actRoute: ActivatedRoute,
    private productData: ProductDataService
  ) {
    this.name = this.actRoute.snapshot.params.name;
    this.products = this.productData.getAllData();
  }

  ngOnInit() {
    this.products = this.products.filter((product: any) => {
      return product.name === this.name;
    });
  }

  
}
