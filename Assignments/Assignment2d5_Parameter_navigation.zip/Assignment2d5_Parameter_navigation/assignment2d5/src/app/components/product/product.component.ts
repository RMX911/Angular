import { Component, OnInit } from '@angular/core';
import { ProductDataService } from "../../services/product-data.service";

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
})
export class ProductComponent implements OnInit {
  products: any = [];
  constructor(private productData:ProductDataService) {
    this.products = productData.getAllData();
  }

  ngOnInit(): void {}
}
