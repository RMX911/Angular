import { ModuleWithProviders } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ContactComponent } from "./components/contact/contact.component";
import { HomeComponent } from "./components/home/home.component";
import { ProductComponent } from "./components/product/product.component";
import { ProductDetailsComponent } from "./components/product-details/product-details.component";

const routes: Routes = [

    { path: "home", component: HomeComponent },
    { path: "contact-us", component: ContactComponent },
    { path: "products", component: ProductComponent },
    { path: "product-detail/:name", component: ProductDetailsComponent},
    { path: '', redirectTo: '/home', pathMatch: 'full' },
    { path:'**', redirectTo: '/home', pathMatch: 'full'}
];

export const routing: ModuleWithProviders<any> = RouterModule.forRoot(routes);