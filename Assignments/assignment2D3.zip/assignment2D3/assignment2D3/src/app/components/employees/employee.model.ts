export interface employee{
    firstName: string;
    lastName: string;
    dob: Date;
    id : string;
    jobTitle: string;
    salary: number;
}