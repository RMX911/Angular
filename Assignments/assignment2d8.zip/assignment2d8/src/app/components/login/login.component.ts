import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { LoginService } from './../../services/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  title = 'LOGIN';
  loginForm: FormGroup = this.formBuilder.group({});
  submitted: boolean = false;

  constructor(
    private formBuilder: FormBuilder,
    private loginService: LoginService,
    private router: Router
  ) {}

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  get f() {
    return this.loginForm.controls;
  }

  onFormSubmit() {
    this.submitted = true;
    if (this.loginForm.invalid) {
      return;
    } else if (
      this.loginService.userDetails.filter((user: any) => {
        return (
          user.userName === this.loginForm.value.email &&
          user.password === this.loginForm.value.password
        );
      }).length > 0
    ) {
      sessionStorage.setItem('jwtToken', Math.random().toString(36).substr(2));

      if (
        this.isAdmin(this.loginService.userDetails, this.loginForm.value.email)
      ) {
        sessionStorage.setItem('role','admin')
        this.router.navigate(['/admin']);
      } else {
        console.log('hi')
        sessionStorage.setItem('role', 'user')
        this.router.navigateByUrl('home');
      }
    }
    // else save the data to BE, make an API call
    //console.log(JSON.stringify(this.loginForm.value));
  }

  isAdmin(userDetails: any, username: string): boolean {
    // console.log(userDetails, username )
    if (
      userDetails.filter((user: any) => {
        return user.userName === username && user.role === 'admin';
      }).length > 0
    ) {
      return true;
    }

    return false;
  }
}
