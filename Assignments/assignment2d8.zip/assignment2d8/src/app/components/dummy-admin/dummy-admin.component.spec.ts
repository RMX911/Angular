import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DummyAdminComponent } from './dummy-admin.component';

describe('DummyAdminComponent', () => {
  let component: DummyAdminComponent;
  let fixture: ComponentFixture<DummyAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DummyAdminComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DummyAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
