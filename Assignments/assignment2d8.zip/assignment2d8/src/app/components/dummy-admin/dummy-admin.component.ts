import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dummy-admin',
  templateUrl: './dummy-admin.component.html',
  styleUrls: ['./dummy-admin.component.css']
})
export class DummyAdminComponent implements OnInit {
  constructor(private router: Router) {}

  ngOnInit(): void {}
  logout() {
    sessionStorage.removeItem('jwtToken');
    sessionStorage.clear()
    this.router.navigateByUrl('');
  }
}
