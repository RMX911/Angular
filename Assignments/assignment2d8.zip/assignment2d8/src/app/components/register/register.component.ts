import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { LoginService } from "./../../services/login.service";

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  title = 'LOGIN';
  registerForm: FormGroup = this.formBuilder.group({});
  submitted: boolean = false;

  constructor(private formBuilder: FormBuilder,  private loginService: LoginService, private router: Router) {}

  ngOnInit() {
    this.registerForm = this.formBuilder.group(
      {
        title: ['', Validators.required],
        firstName: ['', Validators.required],
        lastName: ['', Validators.required],
        dob: ['', Validators.required],
        email: ['', [Validators.required, Validators.email]],
        password: ['', [Validators.required, Validators.minLength(6)]],
        confirmPassword: ['', Validators.required],
      },
      {
        validator: this.mustMatch('password', 'confirmPassword'),
      }
    );
  }

  get f() {
    return this.registerForm.controls;
  }

  onFormSubmit() {
    this.submitted = true;
    if (this.registerForm.invalid) {
      return;
    }
    else{
        this.loginService.userDetails.push({
          userName: this.registerForm.value.email,
          password: this.registerForm.value.password,
          role: 'user'
        })
        this.router.navigateByUrl('')
    }

    // else save the data to BE, make an API call
    console.log(JSON.stringify(this.registerForm.value));
  }

  mustMatch(password: string, confirmPassword: string) {
    //return password === confirmPassword; // going to through an error
    return (formGroup: FormGroup) => {
      const pwd = formGroup.controls[password];
      const cnfPwd = formGroup.controls[confirmPassword];

      if (pwd.value !== cnfPwd.value) {
        cnfPwd.setErrors({
          mustMatch: true,
        });
      } else {
        cnfPwd.setErrors(null);
      }
    };
  }
}
