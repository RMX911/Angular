import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  userDetails: any = []
  constructor() { 

    this.userDetails=[{
      userName: "rmx911@r.com",
      password: "qwerty123",
      role: 'admin'
    },
   {
    userName: "asdfg@r.com",
    password: "1234567890",
    role: 'user'

   }]
  }
}
