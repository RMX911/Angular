import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { routing } from "./app.routing";

import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { HomeComponent } from './components/home/home.component';
import { DummyAdminComponent } from './components/dummy-admin/dummy-admin.component';

@NgModule({
  declarations: [AppComponent, LoginComponent, RegisterComponent, HomeComponent,  DummyAdminComponent],
  imports: [BrowserModule, ReactiveFormsModule,routing],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
