import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  startForm: FormGroup = this.formBuilder.group({});
  submitted: boolean = false;
  tripDetails: any = {};
  bookingDeatils: any = {};
  constructor(private formBuilder: FormBuilder) {}

  ngOnInit() {
    this.startForm = this.formBuilder.group(
      {
        name: ['', Validators.required],
        phoneNumber: [
          '',
          [
            Validators.required,
            Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$'),
          ],
        ],
        address: ['', Validators.required],
        city: ['', Validators.required],
        email: ['', [Validators.required, Validators.email]],
        password: ['', Validators.required],
        confirmPassword: ['', Validators.required],
      },
      {
        validator: this.mustMatch('password', 'confirmPassword'),
      }
    );
  }

  get f() {
    return this.startForm.controls;
  }

  mustMatch(password: string, confirmPassword: string) {
    return (formGroup: FormGroup) => {
      const pwd = formGroup.controls[password];
      const cnfpwd = formGroup.controls[confirmPassword];

      if (pwd.value !== cnfpwd.value) {
        cnfpwd.setErrors({
          mustMatch: true
        });
      }
    };
  }

  submitForm() {
    this.submitted = true;
    if (this.startForm.invalid) {
      return;
    } else {
      console.log(this.startForm.value);
    }
  }
}
