export interface employee{
    firstName: string;
    lastName: string;
    age: number;
    id : string;
    profileImage: string;
    salary: number;
}